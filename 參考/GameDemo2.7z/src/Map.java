import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import java.io.*;
import javax.imageio.*;

public class Map extends JPanel {
	String mapName; 
	
	static int[][] map1=new int[40][300];
	
	
	public Map(){
		
		for(int a=0;a<40;a++){
			for(int b=0;b<300;b++){
				map1[a][b]=0;
			}
		}
		
		for(int a=20;a<21;a++){
			for(int b=70;b<300;b++){
				map1[a][b]=1;
			}
		}
		
		for(int a=21;a<40;a++){
			for(int b=0;b<300;b++){
				map1[a][b]=1;
			}
		}
		
		
		
		
	}
	
	
	
	
	
}
