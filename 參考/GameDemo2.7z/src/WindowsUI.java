import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class WindowsUI extends JFrame implements GameConfig{
	JPanel panel;
	Ball ball;
	Map map;
	
	public WindowsUI(){
		setTitle("The Pavane of Vatican");
	}
	
	public void Start(){
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(frameX,frameY);
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(3);
		panel = setPanel();
		
		//安裝面板
		this.add(panel);
		
		//安裝Listener
		PanelListener plis = new PanelListener();
		this.addKeyListener(plis);
		
		//載入地圖
		map=new Map();
		
		//啟動人物
		ball= new Ball();
		ball.start();
		

		
		
		//面板刷新
		UpdateThread ut = new UpdateThread(panel);
		ut.start();
		
		
	}
	
	
	public JPanel setPanel(){  
        JPanel panel = new MyPanel();  
        panel.setPreferredSize(new Dimension(panelX, panelY));  
        panel.setLayout(null);  
        panel.setBackground(Color.white);  
          
        return panel;  
    }  
	
	//Listener
	class PanelListener extends KeyAdapter{
		
		//當按鈕按下
		public void keyPressed(KeyEvent e){
			int code = e.getKeyCode();
			switch(code){
				case KeyEvent.VK_RIGHT:
					ball.right=true;
					break;
				case KeyEvent.VK_LEFT:
					ball.left=true;
					break;
				case KeyEvent.VK_UP:
					ball.up=true;
					break;

				
			}
		}
		
		public void keyReleased(KeyEvent e){
			int code = e.getKeyCode();
			switch(code){
				case KeyEvent.VK_RIGHT:
					ball.right=false;
					break;
				case KeyEvent.VK_LEFT:
					ball.left=false;
					break;
				case KeyEvent.VK_UP:
					ball.up=false;
					break;
				
			}
		}
		
	}
	
	
	//建構遊戲畫面
	class MyPanel extends JPanel{
		
		@Override
		public void paint(Graphics g){
			super.paint(g);
			
			
			
			 for(int i=ball.getI()-9;i<=ball.getI()+5;i++){  
	                for(int j=ball.getJ()-13;j<=ball.getJ()+13;j++){  
	                    
	                	 //畫地圖
                        ImageIcon icon = GetIcon.int2icon(Map.map1[i][j]);  
                        g.drawImage(icon.getImage(), (13+j-ball.getJ())*elesize, (9+i-ball.getI())*elesize, elesize, elesize, null);  
	                }  
	                
	               
			 }
			 //畫角色
			 g.drawImage(icon1.getImage(), ball.px, ball.py, null);  
		}
	}
	
	
	class UpdateThread extends Thread{
		JPanel panel;
		public UpdateThread(JPanel panel){
			this.panel=panel;
		}
		
		@Override
		public void run(){
			while(true){
				panel.repaint();
				try{
					Thread.sleep(10);
				}	catch(InterruptedException e){
					e.printStackTrace();
				}
			}
		}
	}
}
