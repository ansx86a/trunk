import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;
import java.io.*;

public abstract class Character extends Thread implements GameConfig{
	
    //角色中點相對遊戲畫面的位置(在遊戲中不變)  
    int px = panelX/2;  
    int py = 50*9;  
    //角色中點在整張地圖中的位置
    int x = 3000;  
    int y = 1000;  
    //角色的步長
    int step = 10;  
    //角色是否移动  
    boolean up = false;  
    boolean down = false;  
    boolean left = false;  
    boolean right = false;   
    
    //Map map;
    
    
    /*public Character(Map map){
    	this.map=map;
    }*/
    
	@Override  
	public void run() {  
	    while(true){  
	        move();  
	        moveUD();
	        try {  
	            Thread.sleep(20);  
	        } catch (InterruptedException e) {  
	            e.printStackTrace();  
	        }
	        
	    }  
	}  
	  
	/** 
	 * 角色移动的方法 
	 */  
	public void move(){  
		
	    if(left){  
	    	System.out.printf("%d %d\n", this.getI(), this.getJ());
	    	if(Map.map1[this.getI()][this.getJ()-1]!=0){  }
	    	else if(Map.map1[this.getI()][this.getJ()-1]==0){  
                x=x-step;   
            }    
	    }  
	    if(right){  
	    	System.out.printf("%d %d\n", this.getI(), this.getJ());
	    	if(Map.map1[this.getI()][this.getJ()+1]!=0){ }
	    	else if(Map.map1[this.getI()][this.getJ()+1]==0){  
                x=x+step;  
            } 
	    }
	}  
	
	public void moveUD(){
		if(up){  
			System.out.printf("%d %d\n", this.getI(), this.getJ());
   	   
			if(Map.map1[this.getI()-1][this.getJ()]!=0){  }
			else if(Map.map1[this.getI()-1][this.getJ()]==0){
				y=y-step;  
			}  
		}
		/*if(down){  
			System.out.printf("%d %d\n", this.getI(), this.getJ());
			if(Map.map1[this.getI()+1][this.getJ()]!=0){  }
			else if(Map.map1[this.getI()+1][this.getJ()]==0){  
				y=y+step;  
			}    
		}  */
	}
	
	/*public void jump(){
		
		if(up){
			for(int a=0;a<2;a++){
				System.out.printf("%d %d\n", this.getI(), this.getJ());
				if(Map.map1[this.getI()-1][this.getJ()]!=0){  
					
				}else if(Map.map1[this.getI()-1][this.getJ()]==0){ 
					y=y-50;  
				}
			}
		
			while(true){
				System.out.printf("%d %d\n", this.getI(), this.getJ());
				y=y+50;  
				if(Map.map1[this.getI()+1][this.getJ()]!=0){  
					break;
				}else if(Map.map1[this.getI()+1][this.getJ()]==0){  
					
                
				}  
			}
		}
             
		
	}*/
	
	public void fall(){
		while(true){
			if(Map.map1[this.getI()+1][this.getJ()]!=0){  
	            break;
		    }else if(Map.map1[this.getI()+1][this.getJ()]==0){  
		           y=y+step;
		    }    
		     
		}
	}
	
	//得到角色在地圖中的位置I  
	public int getI(){  
	    
		
		return y/elesize;
	}  
	//得到角色在地圖中的位置J  
	public int getJ(){  
	      
		
		return x/elesize;
	}  

}

