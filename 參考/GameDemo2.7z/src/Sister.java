import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;


public class Sister extends Character implements GameConfig {

	

}
