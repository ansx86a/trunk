
public class Main {

	public static void main(String[] args) {
		
		
			WindowsUI wui = new WindowsUI();
			
			wui.Start();
			wui.setVisible(true);
			
			
			
	}

}
