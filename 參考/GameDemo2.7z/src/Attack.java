
public interface Attack {

}
