
public class Ball extends Character implements GameConfig {
	
	
	
}
