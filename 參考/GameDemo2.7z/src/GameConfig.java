import javax.swing.*;
import java.awt.*;


public interface GameConfig {
	
	int frameX=1500;	//frame長
	int frameY=800;		//frame高
	int panelX=1300;	//畫面長
	int panelY=750;		//畫面高
	int elesize=50;		//素材大小
	int playersize=50;	//玩家大小
	//遊戲圖片
	ImageIcon icon1 = new ImageIcon("test3.png");	//球
	ImageIcon icon2 = new ImageIcon("test5.png");	//地板
	ImageIcon icon3 = new ImageIcon("test1.png");	//透明
	ImageIcon icon4 = new ImageIcon("test4.png");
}
