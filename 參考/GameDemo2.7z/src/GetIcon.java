import javax.swing.*;


public class GetIcon implements GameConfig {
	
	static ImageIcon int2icon(int n){
		if(n==0)	return icon3;
		else if(n==1)	return icon2;
		else if(n==2)	return icon4;
		else if(n==200)	return icon1;
		
		return null;
	}
}
